'use client';

import { useState, useEffect } from "react";
import OrderBox from "@/app/comp/orderComp/theOrder";
import NavForOrder from "@/app/comp/orderComp/navOrder";
import "./ord.css";

export default function Order() {
    // State Management
    const [db, setDb] = useState([]);
    const [filtered, setFiltered] = useState("");
    const [search, setSearch] = useState("");
    const [selectedItems, setSelectedItems] = useState([]);
    const [isCartVisible, setIsCartVisible] = useState(false);
    const [isClicked, setClicked] = useState(false);
    const [currentItem, setCurrentItem] = useState(null);
    const [more, setMore] = useState(1);
    const [loading, setLoading] = useState(true);

    // Fetch Data
    useEffect(() => {
        fetch("http://localhost:3000//api/dishs")
            .then((res) => res.json())
            .then((data) => {
                setDb(data);
                setLoading(false);
            })
            .catch((error) => {
                console.error("Error fetching data:", error);
                setLoading(false);
            });
    }, []);

    // Filtering food based on search and category
    const filteredFood = db.filter((food) =>
        food.offerName.toLowerCase().includes(search.toLowerCase()) &&
        (filtered === "" || food.type === filtered)
    );

    // Handlers
    const addItemForMain = (food) => {
        setCurrentItem(food);
        setClicked(true);
        setMore(1);
    };

    const addItemForCheck = (food) => {
        setSelectedItems((prevItems) => {
            const existingItem = prevItems.find((item) => item.offerName === food.offerName);
            if (existingItem) {
                return prevItems.map((item) =>
                    item.offerName === food.offerName
                        ? { ...item, quantity: item.quantity + more }
                        : item
                );
            } else {
                return [...prevItems, { ...food, quantity: more }];
            }
        });
        setMore(1);
        setClicked(false);
        setIsCartVisible(true);
    };

    const toggleCart = () => {
        setIsCartVisible(!isCartVisible);
    };

    const updateData = async (dishName, newpiece) => {
        try {
            const response = await fetch(`/api/dishs`, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ dishName, newpiece }),
            });

            if (!response.ok) {
                throw new Error("Failed to update data");
            }

            return await response.json();
        } catch (error) {
            console.error("Error updating data:", error);
        }
    };

    const handleCheckout = () => {
        if (localStorage.getItem("logged_in") === "true") {
            setSelectedItems([]);
            setCurrentItem(null);
            setClicked(false);
            setIsCartVisible(false);
            alert("Have a nice meal!");
        } else {
            alert("You need to log in");
        }
    };

    const handleOrder = async () => {
        if (!currentItem) return;

        const food = db.find((item) => item.offerName === currentItem.offerName);
        if (!food) {
            console.error("Food not found in database.");
            return;
        }

        if (food.piece < more) {
            console.log("Not enough stock available.");
            return;
        }

        addItemForCheck(currentItem);

        // Update the stock in database
        const newStock = food.piece - more;
        await updateData(food.offerName, newStock);

        // Update local state
        setDb((prevDb) =>
            prevDb.map((item) =>
                item.offerName === food.offerName ? { ...item, piece: newStock } : item
            )
        );
    };

    const calcMoney = (item) => {
        if (item.discount > 0) {
            return item.price - (item.price * item.discount / 100);
        } else {
            return (item.price * item.quantity);
        }
    };

    return (
        <>
            {/* Navbar for Filtering and Search */}
            <NavForOrder>
                <button onClick={() => setFiltered("")} className="nav-btn">All</button>
                <button onClick={() => setFiltered("classic")} className="nav-btn">Classic</button>
                <button onClick={() => setFiltered("grilled")} className="nav-btn">Grilled</button>
                <button onClick={() => setFiltered("soups")} className="nav-btn">Soups</button>
                <button onClick={() => setFiltered("drinks")} className="nav-btn">Drink</button>
                <input
                    type="text"
                    placeholder={`Search ${filtered === "" ? "for Dishes" : "in " + filtered}`}
                    style={{ color: "black" }}
                    onChange={(e) => setSearch(e.target.value)}
                />
                <button onClick={() => setFiltered("alcoholic")} className="nav-btn">Alcoholic</button>
                <button onClick={() => setFiltered("appetizers")} className="nav-btn">Appetizers</button>
                <button style={{ fontSize: 25 }} onClick={toggleCart}>🛒</button>
            </NavForOrder>

            {/* Cart Section */}
            <div className={`order-cart ${isCartVisible ? 'visible' : ''}`}>
                <button className="close-btn" onClick={toggleCart}>❌</button>
                <div className="order-cart-items">
                    <h2 className="order-cart-title">In Cart:</h2>
                    {selectedItems.length > 0 ? (
                        <>
                            {selectedItems.map((item, index) => (
                                <div className="order-cart-item" key={index}>
                                    <p className="order-cart-item-text">
                                        {item.quantity}x {item.offerName} — {Math.floor(calcMoney(item))} LE
                                    </p>
                                </div>
                            ))}
                            <p>
                                Total: {Math.floor(selectedItems.reduce((acc, item) => acc + calcMoney(item), 0))} LE
                            </p>
                            <button className="order-checkout-btn" onClick={handleCheckout}>
                                Checkout
                            </button>
                        </>
                    ) : (
                        <p className="order-cart-empty">No items selected yet.</p>
                    )}
                </div>
            </div>

            {/* Item Popup */}
            {currentItem && (
                <div className={`order-det ${isClicked ? 'visible' : ''}`}>
                    <button className="close-btn" onClick={() => setClicked(false)}>❌</button>
                    <img src={currentItem.img} alt={currentItem.offerName} className="order-img" />
                    <p className="order-name">{currentItem.offerName}</p>
                    <p>Add more pieces?</p>
                    <div className="quantity-controls">
                        <button onClick={() => setMore(more + 1)}>+</button>
                        <span>{more}</span>
                        <button onClick={() => setMore(Math.max(more - 1, 1))}>-</button>
                    </div>
                    <p className="order-price">{currentItem.price * more} LE</p>
                    <button className="order-btn" onClick={handleOrder}>Order</button>
                </div>
            )}

            {/* Main Food List */}
            <main className="order-main">
                {loading ? (
                    <div className="flex justify-center items-center mt-4 py-60">
                        <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
                    </div>
                ) : filteredFood.length > 0 ? (
                    filteredFood.map((food, index) => (
                        <OrderBox props={food} key={index}>
                            <button type="button" className="order-add-btn" onClick={() => addItemForMain(food)}>
                                Order
                            </button>
                        </OrderBox>
                    ))
                ) : (
                    <p className="order-no-dish">We don't have this dish yet :/</p>
                )}
            </main>
        </>
    );
}
