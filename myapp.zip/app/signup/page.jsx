'use client'
import "./page.css"
import { useState, useEffect } from "react";
import { useRouter } from 'next/navigation';
import { EyeOff, Eye } from 'lucide-react';

export default function Order() {
    const [showPassword, setShowPassword] = useState(false);
    const [showcPassword, setShowcPassword] = useState(false);
    const [loading, setLoading] = useState(false);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confPassword, setConfPassword] = useState('');
    const [email, setEmail] = useState('');
    const [img, setImg] = useState(null);
    const [imgState, setImgState] = useState(false);
    const [emailMessage, setEmailMessage] = useState('');
    const [userNameMessage, setUserNameMessage] = useState('');
    const [passwordMessage, setPasswordMessage] = useState('');
    const [confPasswordMe, setConfPasswordMe] = useState('');
    const [isLoggedin, setLoggedIn] = useState(false);
    const router = useRouter();

    useEffect(() => {
        const log = localStorage.getItem("logged_in") === "true";
        setLoggedIn(log);
    }, []);

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setImgState(true);
            const reader = new FileReader();
            reader.onload = () => setImg(reader.result);
            reader.readAsDataURL(file);
        }
    };

    const checkEmail = (e) => {
        const value = e.target.value;
        setEmail(value);
        setEmailMessage(value.includes("@") && value.lastIndexOf(".") > value.indexOf("@") + 1 ? "rgb(42, 218, 39)" : "red");
    };

    const checkUsername = (e) => {
        const value = e.target.value;
        setUsername(value);
        setUserNameMessage(value.length >= 7 && value.length < 12 ? "rgb(42, 218, 39)" : "red");
    };

    const checkPassword = (e) => {
        const value = e.target.value;
        setPassword(value);
        setPasswordMessage(value.length >= 7 && value.length < 12 ? "rgb(42, 218, 39)" : "red");
    };

    const checkValid = async (e) => {
        e.preventDefault();

        if (!imgState) {
            setConfPasswordMe("Please choose a profile pic");
            return;
        }

        if (
            email.includes("@") && email.lastIndexOf(".") > email.indexOf("@") + 1 &&
            username.length >= 7 && username.length < 12 &&
            password.length >= 7 && password.length < 12 &&
            password === confPassword
        ) {
            setLoading(true);

            try {
                const res = await fetch('/api/users', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        name: username,
                        password,
                        email,
                        img,
                    }),
                });

                setLoading(false);

                if (res.ok) {
                    localStorage.setItem("logged_in", "true");
                    localStorage.setItem("loggedInUser", JSON.stringify({ name: username, email, img }));
                    setTimeout(() => {
                        window.location.reload();
                    }, 1);
                    router.push('/order');

                } else {
                    const data = await res.json();
                    setConfPasswordMe(data.message || 'An error occurred');
                }
            } catch (error) {
                setConfPasswordMe('Server error, please try again');
            }
        } else {
            setConfPasswordMe('✖ Check your inputs');
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center mt-4 py-60">
            <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin "></div>
        </div>
    }

    if (isLoggedin) {
        return <div>Logged</div>
    }

    return (
        <form className="form-container" onSubmit={checkValid}>
            <div style={{ display: "flex", margin: "10px", textAlign: "center" }}>
                <p style={{ color: "blueviolet", fontSize: "30px", margin: "20px" }}>Welcome !</p>
                {img && <img src={img} style={{ marginTop: "-5px" }} alt="Preview" className="img-preview" />}
            </div>

            <div className="input-container">
                <input onChange={checkUsername} value={username} className="name-in" placeholder=" " />
                <label className="floating-label" style={{ color: userNameMessage }}>Enter your username</label>
            </div>

            <div className="input-container">
                <input onChange={checkEmail} value={email} className="name-in" placeholder=" " />
                <label className="floating-label" style={{ color: emailMessage }}>Enter your email</label>
            </div>

            <div className="input-container">
                <input
                    onChange={checkPassword}
                    value={password}
                    className="name-in"
                    placeholder=" "
                    type={showPassword ? "text" : "password"}
                />
                <label className="floating-label" style={{ color: passwordMessage }}>Enter your password</label>
                <button className="showPass" type="button" onClick={() => setShowPassword(!showPassword)}>
                    {showPassword ? <Eye /> : <EyeOff />}
                </button>
            </div>

            <div className="input-container">
                <input
                    onChange={(e) => setConfPassword(e.target.value)}
                    value={confPassword}
                    className="name-in"
                    placeholder=" "
                    type={showcPassword ? "text" : "password"}
                    style={{ marginTop: "-20px" }}
                />
                <label className="floating-label" style={{ marginTop: "-16px" }}>Confirm your password</label>
                <button className="showPass" type="button" onClick={() => setShowcPassword(!showcPassword)}>
                    {showcPassword ? <Eye /> : <EyeOff />}
                </button>
                <p style={{
                    textAlign: "center",
                    color: "blueviolet",
                    fontSize: "17px",
                    fontWeight: "bold",
                    fontFamily: "Arial, sans-serif",
                    marginTop: "5px"
                }}>
                    {confPasswordMe}
                </p>
            </div>

            <label htmlFor="img-in" className="file-label" style={{ marginTop: "-50px" }}>Choose your profile pic</label>
            <input type="file" id="img-in" accept="image/*" onChange={handleImageChange} style={{ display: "none" }} />

            <button type="submit" className="signupp color">SignUp</button>
        </form>
    );
}
