import { NextResponse } from "next/server";
import connect from "@/app/util/dbCon";
import User from "@/app/util/models/users";
import { Types } from "mongoose";
export const GET = async () => {
    try {
        await connect();
        const users = await User.find();
        return NextResponse.json(users, { status: 200 });
    } catch (e) {
        console.error(e);
        return NextResponse.error();
    }
}


export const POST = async (req) => {
    try {
        await connect();
        const body = await req.json();

        // Ensure required fields are present
        if (!body.name || !body.email || !body.password) {
            return NextResponse.json({ message: "Username, email, and name are required" }, { status: 400 });
        }

        // Check for duplicate username
        const existingUser = await User.findOne({ name: body.name });
        if (existingUser) {
            return NextResponse.json({ message: "Username is already taken, try another" }, { status: 400 });
        }

        // Check for duplicate email
        const existingEmail = await User.findOne({ email: body.email });
        if (existingEmail) {
            return NextResponse.json({ message: "Email is already used" }, { status: 400 });
        }

       

        // Create and save new user
        const newUser = new User(body);
        await newUser.save();

        return NextResponse.json({ message: "User created successfully", user: newUser }, { status: 201 });
    } catch (e) {
        console.error("Registration error:", e);
        return NextResponse.json({ message: "Internal Server Error" }, { status: 500 });
    }
};

export const PATCH = async (req) => {
    try {
        const body = await req.json();
        const { userId, newUsername } = body;

        if (!userId || !newUsername) {
            return NextResponse.json({ error: "ID OR NEW USERNAME NOT PROVIDED" }, { status: 400 });
        }

        if (!Types.ObjectId.isValid(userId)) {
            return NextResponse.json({ error: "INVALID ID" }, { status: 400 });
        }

        await connect();

        const updatedUser = await User.findOneAndUpdate(
            { _id: userId },
            { username: newUsername },
            { new: true }
        );

        if (!updatedUser) {
            return NextResponse.json({ error: "USER NOT FOUND" }, { status: 404 });
        }

        return NextResponse.json(updatedUser, { status: 200 });
    } catch (e) {
        console.error(e);
        return NextResponse.json({ error: "INTERNAL SERVER ERROR" }, { status: 500 });
    }
};
export const DELETE = async (req) => {
    try {
        const { searchParams } = new URL(req.url);
        const userId = searchParams.get("userId");

        if (!userId) {
            return NextResponse.json({ error: "ID NOT PROVIDED" }, { status: 400 });
        }

        if (!Types.ObjectId.isValid(userId)) {
            return NextResponse.json({ error: "INVALID ID" }, { status: 400 });
        }

        await connect();

        const deletedUser = await User.findByIdAndDelete(userId);

        if (!deletedUser) {
            return NextResponse.json({ error: "USER NOT FOUND OR ALREADY DELETED" }, { status: 404 });
        }

        return NextResponse.json({ message: "USER DELETED SUCCESSFULLY", deletedUser }, { status: 200 });
    } catch (e) {
        console.error("DELETE ERROR:", e);
        return NextResponse.json({ error: "INTERNAL SERVER ERROR", details: e.message }, { status: 500 });
    }
};
