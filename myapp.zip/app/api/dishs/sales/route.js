import connect from "@/app/util/dbCon";
import Offers from "@/app/util/models/offers";
import { NextResponse } from "next/server";
export const GET = async () => {
    try {
        await connect();
        const offers = await Offers.find();
        return NextResponse.json(offers, { status: 200 });
    } catch (e) {
        console.error(e);
        return NextResponse.json({ error: "INTERNAL SERVER ERROR" }, { status: 500 });
    }
}

export async function POST(req) {
    try {
        const body = await req.json();
        await connect();
        const newOffer = new Offers(body);
        await newOffer.save();
        return NextResponse.json(newOffer, { status: 201 });
    } catch (e) {
        console.error(e);
        return NextResponse.json({ error: "INTERNAL SERVER ERROR" }, { status: 500 });
    }
}
