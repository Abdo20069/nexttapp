import { NextResponse } from "next/server";
import connect from "@/app/util/dbCon";
import Offers from "@/app/util/models/offers";
export const GET = async () => {
    try {
        await connect();
        const dishs = await Offers.find();
        return NextResponse.json(dishs, { status: 200 });
    } catch (e) {
        console.error(e);
        return NextResponse.error();
    }
}
export const POST = async (req) => {
    try {
        const body = await req.json();
        await connect();
        const newDish = new Offers(body);
        await newDish.save();
        return NextResponse.json(newDish, { status: 201 });

    } catch (e) {
        console.error(e);
        return NextResponse.error();
    }
}
export const PATCH = async (req) => {
    try {
        const body = await req.json();
        const { dishName, newpiece } = body;

        if (!dishName || !newpiece) {
            return NextResponse.json({ error: "DISH NAME OR NEW PIECE NOT PROVIDED" }, { status: 400 });
        }

        await connect();

        const updatePiece = await Offers.findOneAndUpdate(
            { offerName: dishName }, // Assuming dishName is a unique string field
            { piece: newpiece },
            { new: true }
        );

        if (!updatePiece) {
            return NextResponse.json({ error: "DISH NOT FOUND OR UPDATE FAILED" }, { status: 404 });
        }

        return NextResponse.json(updatePiece, { status: 200 });

    } catch (e) {
        return NextResponse.json({ error: "INTERNAL SERVER ERROR" }, { status: 500 });
    }
};

