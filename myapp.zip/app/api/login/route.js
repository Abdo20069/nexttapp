import dbConnect from "@/app/util/dbCon";
import User from "@/app/util/models/users";

export async function POST(req) {
    try {
        await dbConnect();

        const { name, password } = await req.json(); // Read request body

        if (!name || !password) {
            return new Response(JSON.stringify({ message: "Username and password are required" }), { status: 400 });
        }

        const user = await User.findOne({ name });


        if (!user) {
            return new Response(JSON.stringify({ message: "User not found" }), { status: 401 });
        }

        // Direct password comparison (NO HASHING, NO TOKEN)
        if (password !== user.password) {
            return new Response(JSON.stringify({ message: "Invalid password" }), { status: 401 });
        }

        return new Response(JSON.stringify({ message: "Login successful", user: { name: user.name, email: user.email, img: user.img } }), { status: 200 });

    } catch (error) {
        console.error("Login error:", error);
        return new Response(JSON.stringify({ message: "Server error", error: error.message }), { status: 500 });
    }
}
export async function GET() {
    return new Response(JSON.parse(POST()), { status: 405 });
}