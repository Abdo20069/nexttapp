import mongoose from "mongoose";
const Db_url = process.env.DB_URL;
const connect = async () => {
    const connectionState = mongoose.connection.readyState;
    if (connectionState === 1) {
        console.log("Already connected to the database");
        return;
    }

    if (connectionState === 2) {
        console.log("Connecting to the database");
        return;
    }

    try {
        mongoose.connect(Db_url, {
            dbName: "test",
            bufferCommands: true,

        });
        console.log("Connected to the database");
    }
    catch (e) {
        console.error("Error connecting to the database");
        console.error(e);
    }

}
export default connect;
