import { Schema, model, models } from "mongoose";

const dishSchema = new Schema({
    dishName: {
        type: String,
        required: true,
        unique: true,
    },
    price: {
        type: Number,
        required: true,
    },
    type: {
        type: String,
        required: true,
    },
    img: {
        type: String,
        required: true,
    },
    piece: {
        type: Number,
        required: true,
    },
    discount: {
        type: Number,
        
    },
    expireAt: {  // Add expiration date for discount
        type: Date,
        
    },
}, { timestamps: false });

// Middleware to remove discount if expired before returning data
dishSchema.methods.toJSON = function () {
    const dish = this.toObject();
    if (new Date() > new Date(dish.expireAt)) {
        dish.discount = 0; // Remove discount if expired
    }
    return dish;
};

export default models.Dish || model("Dish", dishSchema);
