import { Schema, model, models } from "mongoose";

const offerSchema = new Schema(
    {
        offerName: {
            type: String,
            required: true,
            unique: true,
        },
        discount: {
            type: Number,
            required: true,
        },
        piece: {
            type: Number,
            required: true,
        },
        img: {
            type: String,
            required: true,
        },
        price: {
            type: Number,
            required: true
        },
        type: {
            type: String,
            required: true,
        },
        expireAt: {
            type: Date,
            required: true,
            index: { expires: 0 } // TTL Index
        }
    },
    {
        timestamps: true, // Keeps track of createdAt and updatedAt
    }
);

export default models.Offer || model("Offer", offerSchema);
