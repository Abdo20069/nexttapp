"use client";
import { useState, useEffect } from "react";
import Fblock from "@/app/comp/newBlock/fristBlock";
import FoodBlock from "@/app/comp/newBlock/foodBlock";
export default function Home() {
  const [retrievedUser, setRetrievedUser] = useState(null);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("logged_in"));
    setRetrievedUser(user);
  }, []); // Runs only once when component mounts


  return (
    <main>
      <Fblock token={retrievedUser ? true : false} />
      <FoodBlock />
    </main>
  );
}
