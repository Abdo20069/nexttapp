'use client';
import { useState, useEffect } from "react";
import { EyeOff, Eye } from 'lucide-react';
import { useRouter } from 'next/navigation';
import "./page.css";

export default function Order(e) {
    const router = useRouter();
    const [showPassword, setShowPassword] = useState(false);
    const [password, setPassword] = useState("");
    const [username, setUsername] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [isLoggedin, setLoggedIn] = useState(false);

    useEffect(() => {
        const log = localStorage.getItem("logged_in") === "true";
        setLoggedIn(log);
     
    }, [router]);

    const checkLogin = async () => {
        setLoading(true);
        setError(""); // Reset error on new attempt
        try {
            const res = await fetch("/api/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name: username, password }),
            });

            const responseText = await res.text(); // Read raw response

            if (!res.ok) {
                try {
                    const errorData = JSON.parse(responseText);
                    throw new Error(errorData.message || "Login failed");
                } catch {
                    throw new Error(responseText || "Login failed");
                }
            }

            const data = JSON.parse(responseText);
            localStorage.setItem("logged_in", "true");
            localStorage.setItem("loggedInUser", JSON.stringify(data.user));
            setTimeout(() => {
                window.location.reload();
            }, 1); // 3000ms = 3 seconds
            router.push("/");
        } catch (error) {
            setError(error.message);
        } finally {
            setLoading(false);
        }
    };
    if (isLoggedin) {
        return <p>You are already logged in</p>;
    }

    return (
        <main className="form-container">
            <p className="login-title">Welcome back!</p>

            {error && <p className="error-message">{error}</p>}

            <div className="input-container">
                <input
                    className="name-in"
                    required
                    placeholder=" "
                    onChange={(e) => setUsername(e.target.value)}
                    value={username}
                />
                <label className="floating-label">Enter your username or email</label>
            </div>

            <div className="input-container">
                <input
                    className="name-in"
                    type={showPassword ? "text" : "password"}
                    required
                    placeholder=" "
                    onChange={(e) => setPassword(e.target.value)}
                    value={password}
                />
                <label className="floating-label">Enter your password</label>
                <button className="showPasss" type="button" onClick={() => setShowPassword(!showPassword)}>
                    {showPassword ? <Eye /> : <EyeOff />}
                </button>
            </div>

            <button className="signupp" onClick={checkLogin} disabled={loading}>
                {loading ? "Logging in..." : "Log in"}
            </button>
        </main>
    );
}
