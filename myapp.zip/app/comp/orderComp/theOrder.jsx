import { useEffect, useState } from "react";
import "./order.css";

export default function OrderBox({ props, children }) {
    const [timeLeft, setTimeLeft] = useState("");
    const [isExpired, setIsExpired] = useState(false); // Track expiration

    useEffect(() => {
        if (!props.expireAt) return;

        const updateCountdown = () => {
            const now = new Date();
            const expireTime = new Date(props.expireAt);
            const diff = expireTime - now; // Recalculate every second

            if (diff > 0) {
                const days = Math.floor(diff / (1000 * 60 * 60 * 24));
                const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
                const minutes = Math.floor((diff / (1000 * 60)) % 60);
                const seconds = Math.floor((diff / 1000) % 60);
                setTimeLeft(`${days}d ${hours}h ${minutes}m ${seconds}s`);
                setIsExpired(false); // Discount still valid
            } else {
                setTimeLeft("Expired");
                setIsExpired(true); // Mark discount as expired
            }
        };

        updateCountdown(); // Run immediately
        const interval = setInterval(updateCountdown, 1000); // Update every second

        return () => clearInterval(interval); // Cleanup on unmount
    }, [props.expireAt]); // Dependency

    return (
        <div className="flex">
            <div className="order-box">
                <p style={{ color: "black", fontWeight: "300", fontSize: "20px" }}>{props.offerName}</p>
                <img src={props.img} className="img" loading="lazy" alt={props.dishName} />
                <span></span>{!isExpired && props.discount > 0 && <p>{props.discount} % discount</p>}
                <p> <span style={{ color: "blueviolet", fontWeight: "600", fontSize: "22px" }}> {props.price}</span>LE</p>
                <p><span style={{ color: "blueviolet", fontWeight: "600", fontSize: "22px" }}>{props.piece}</span> piece left</p>
                {!isExpired && props.discount > 0 && <p>Discount Expires in:</p>}
                {!isExpired && props.discount > 0 && <p style={{ color: "blueviolet", fontWeight: "600", fontSize: "22px" }}>{timeLeft}</p>}

                {children}
            </div>
        </div >
    );
}
