import "./nav.css"
import Link from "next/link"
export default function navForOrder({ children }) {

    return (
        <main>
            <div className="nav-box">
                {children}

                {/*   <Link href="/order" className="nav-btn">Home</Link>
                <Link href="/order/Griled" className="nav-btn">Grild</Link>
                <Link href="/order/classic" className="nav-btn">classic</Link>
                <Link href="/order/soups" className="nav-btn">soups</Link>
                <Link href="/order/Drinks" className="nav-btn">Drinks</Link>*/

                /*<Link href="/order/alc" className="nav-btn">Alchoilc Drinks</Link>
                <Link href="/order/dessert" className="nav-btn">dessert</Link>
                <Link href="/order/addUps" className="nav-btn">add ups</Link>*/}
            </div>
        </main>
    )
}