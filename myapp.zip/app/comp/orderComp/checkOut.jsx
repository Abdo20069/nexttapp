'use client'
import { useState } from "react";

export default function CheckOut({ items = [] }) { // Default to empty array
    const [isCartVisible, setIsCartVisible] = useState(true);

    const toggleCart = () => {
        setIsCartVisible(!isCartVisible);
    };

    const handleCheckout = () => {
        alert("Checkout complete!");
    };

    return (
        <div className={`order-cart ${isCartVisible ? 'visible' : ''}`}>
            <div className="order-cart-items">
                <h2 className="order-cart-title">In Cart:</h2>
                {items.length > 0 ? (
                    <>

                        <div className="order-cart-item" >
                            <p className="order-cart-item-text">
                                {items.quantity}x {items.name} — {items.price * items.quantity} LE
                            </p>
                        </div>

                        <p>
                            Total: {items.reduce((acc, item) => acc + item.price * item.quantity, 0)} LE
                        </p>
                        <button className="order-checkout-btn" onClick={handleCheckout}>
                            Checkout
                        </button>
                    </>
                ) : (
                    <p className="order-cart-empty">No items selected yet.</p>
                )}
            </div>
        </div>
    );
}
