'use client'
import Link from 'next/link'
import "./header.css"
import Profile from "@/app/comp/profile/profile"
import { useState, useEffect } from 'react'

export default function Header() {
    const [user, setUser] = useState(false);

    // Check if user is logged in only after the component mounts on the client side
    useEffect(() => {
        const loggedIn = localStorage.getItem('logged_in') === "true" ? true : false;
        setUser(loggedIn);
    }, []);

    const logout = () => {
        const userChoice = window.confirm("Do you want to logout?");
        if (userChoice) {
            localStorage.setItem('logged_in', "false")
            localStorage.removeItem('loggedInUser');
            window.location.reload();
        }
    }

    return (
        <main>
            <nav className='nav-header'>
                <Profile />
                <Link href="/" className='header-btn'>Home</Link>
                <Link href="/order" className='header-btn'>Order</Link>
                {user && <button className='header-btn' onClick={logout} id="logout">Log out</button>}
                {!user && <>
                    <Link href="/login" className='header-btn' id="login">Login</Link>
                    <Link href="/signup" className='header-btn' id="signup">Signup</Link>
                </>}
            </nav>
        </main>
    )
}
