import "./footer.css"
export default function footer() {
    return (
        <main>
            <div className="block5">
                <a href="google.com" className="footer-a">Who are the chefs</a>
                <a href="google.com" className="footer-a">our location</a>
                <a href="google.com" className="footer-a">our spliers</a>
                <a href="google.com" className="footer-a">The restaurants</a>
                <a href="google.com" className="footer-a">our restaurants</a>
                <a href="google.com" className="footer-a">google</a>
                <a href="google.com" className="footer-a">Who are the chefs</a>
                <a href="google.com" className="footer-a">our location</a>
                <a href="google.com" className="footer-a">our spliers</a>
                <a href="google.com" className="footer-a">The restaurants</a>
                <a href="google.com" className="footer-a">our restaurants</a>
                <a href="google.com" className="footer-a">google</a>
                <a href="google.com" className="footer-a">Who are the chefs</a>
                <a href="google.com" className="footer-a">our location</a>
                <a href="google.com" className="footer-a">our spliers</a>
                <a href="google.com" className="footer-a">The restaurants</a>
                <a href="google.com" className="footer-a">our restaurants</a>
                <a href="google.com" className="footer-a">google</a>
                <a href="google.com" className="footer-a">Who are the chefs</a>
                <a href="google.com" className="footer-a">our location</a>
                <a href="google.com" className="footer-a">our spliers</a>
                <a href="google.com" className="footer-a">The restaurants</a>
            </div>

            <p className="footer-b">©2025</p>
        </main>
    )
}