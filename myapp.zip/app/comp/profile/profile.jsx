'use client'
import { useEffect, useState } from "react";
import "./profile.css";

export default function Profile() {
    const [loggedInUser, setLoggedInUser] = useState(null);
    useEffect(() => {
        const isLogged = JSON.parse(localStorage.getItem("logged_in"))
        if (isLogged) {
            const user = JSON.parse(localStorage.getItem("loggedInUser"));
            setLoggedInUser(user);
        }

    }, []);

    return (
        <div className="profile-container">
            {loggedInUser ? (
                <div className="profile-card">
                    <img src={loggedInUser.img} alt="User Avatar" className="profile-img" />
                    <p className="profile-name">{loggedInUser.name}</p>
                </div>
            ) : (
                <p className="loading-text">signup</p>
            )}
        </div>
    );
}
