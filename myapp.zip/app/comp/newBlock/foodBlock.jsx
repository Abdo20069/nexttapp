"use client";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import "./foodBlock.css";
import Image from "next/image";

export default function FoodBlock() {
    const [data, setData] = useState([]);
    const [error, setError] = useState(null);
    const [timeLeft, setTimeLeft] = useState({});
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const res = await fetch("http://localhost:3000/api/dishs");
                if (!res.ok) throw new Error("Failed to fetch data");
                const result = await res.json();
                setData(result);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    useEffect(() => {
        if (!data.length) return;

        const updateCountdown = () => {
            const now = new Date();
            const newTimeLeft = {};

            data.forEach((offer) => {
                const expireTime = new Date(offer.expireAt);
                const diff = expireTime - now;

                if (diff > 0) {
                    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
                    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);

                    newTimeLeft[offer.offerName] = `Ends in ${days} days and ${hours} hours`;
                } else {
                    newTimeLeft[offer.offerName] = "Expired";
                }
            });

            setTimeLeft(newTimeLeft);
        };

        updateCountdown();
        const interval = setInterval(updateCountdown, 1000);

        return () => clearInterval(interval);
    }, [data]);

    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    const discountCategories = [50, 70, 40, 20, 30];

    return (
        <>
            {discountCategories.map((discount) => (
                <motion.div
                    key={discount}
                    className="dish-slider-container"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                >
                    <h2>{discount}% OFF Deals</h2>
                    <div className="dish-slider">
                        {data
                            .filter((offer) => offer.discount === discount)
                            .map((offer, index) => (
                                <motion.div
                                    key={index}
                                    className="slide-item"
                                    initial={{ opacity: 0, scale: 0.9 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    transition={{ duration: 0.3, delay: index * 0.1 }}
                                >
                                    <img src={offer.img} className="slide-img" alt={offer.offerName || "Dish Image"} priority="false" />
                                    <p>{offer.offerName}</p>
                                    <p>{offer.discount}%</p>
                                    <p>Now: ${(offer.price * (1 - offer.discount / 100)).toFixed(2)}</p>
                                    <p>{timeLeft[offer.offerName] || "Calculating..."}</p>
                                </motion.div>
                            ))}
                    </div>
                </motion.div>
            ))}
        </>
    );
}
