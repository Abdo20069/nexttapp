
'use client'
import "./blockss.css";
import { useEffect, useRef } from "react";
import Link from "next/link"
let imgg = "https://media.gettyimages.com/id/1446478827/photo/a-chef-is-cooking-in-his-restaurants-kitchen.jpg?s=612x612&w=0&k=20&c=jwKJmGErrLe2XsTWNYEEyiNicudYVA4j8jvnTiJdp58=";

export default function Fblock(props) {
    const refs = [useRef(), useRef(), useRef(), useRef(), useRef()];
    useEffect(() => {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("show");
                } else {
                    entry.target.classList.remove("show");
                }
            });
        }, { threshold: 0.3 });

        refs.forEach(ref => {
            if (ref.current) observer.observe(ref.current);
        });

        return () => {
            refs.forEach(ref => {
                if (ref.current) observer.unobserve(ref.current);
            });
        };
    }, []);

    return (


        <main>
            <div ref={refs[3]} className="blocks4 hidden">
                {!props.token &&
                    <><Link href="/signup" className="signup-btn">SINGUP</Link>
                        <p className="pp"> to get alot of COPONES</p>
                    </>}
            </div>

            <div ref={refs[0]} className="blocks hidden">
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem deserunt illum quam cupiditate harum, ex ab temporibus animi magni impedit aspernatur cum minus omnis, ipsam at quia, optio voluptatibus. Nulla.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur deserunt odit eligendi, tempore excepturi voluptatibus temporibus explicabo tenetur debitis, sed necessitatibus laudantium. Incidunt blanditiis corporis, quia nesciunt sequi atque. Optio.
                </p>
                <img src={imgg} alt="Chef Cooking" />

            </div>

            <div ref={refs[1]} className="blocks2 hidden">
                <img src={imgg} alt="Chef Cooking" />
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem deserunt illum quam cupiditate harum, ex ab temporibus animi magni impedit aspernatur cum minus omnis, ipsam at quia, optio voluptatibus. Nulla.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur deserunt odit eligendi, tempore excepturi voluptatibus temporibus explicabo tenetur debitis, sed necessitatibus laudantium. Incidunt blanditiis corporis, quia nesciunt sequi atque. Optio.
                </p>
            </div>

            <div ref={refs[2]} className="blocks3 hidden">
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem deserunt illum quam cupiditate harum, ex ab temporibus animi magni impedit aspernatur cum minus omnis, ipsam at quia, optio voluptatibus. Nulla.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur deserunt odit eligendi, tempore excepturi voluptatibus temporibus explicabo tenetur debitis, sed necessitatibus laudantium. Incidunt blanditiis corporis, quia nesciunt sequi atque. Optio.
                </p>
                <img src={imgg} alt="Chef Cooking" />

            </div>

        </main>

    );
}