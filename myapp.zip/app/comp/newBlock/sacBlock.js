export default function Sblock(){
    return(
        <main>
            
        </main>
    )
}